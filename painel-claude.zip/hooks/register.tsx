import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { Bar, Provider, StyleId, Usage } from '../types'

const PANE = 'hud-ia'
const POLL_MS = 5 * 60_000
const FRAME_MS = 250 // animação: só redesenha, não chama ai-usagebar
const tick = atom({ plugin: 'hud-ia', key: 'tick' } as const, 0)
const usage = atom({ plugin: 'hud-ia', key: 'usage' } as const, null, { shape: 'usage-1' })
const style = atom({ plugin: 'hud-ia', key: 'style' } as const, 'hp' as StyleId)

const STYLES: { id: StyleId; name: string }[] = [
  { id: 'hp', name: 'HP/Mana' },
  { id: 'xp', name: 'XP' },
  { id: 'battery', name: 'Bateria' },
  { id: 'beer', name: 'Cerveja' },
  { id: 'fuel', name: 'Tanque' },
  { id: 'hourglass', name: 'Ampulheta' },
  { id: 'muncher', name: 'Comilão' },
]
const VERTICAL: StyleId[] = ['beer', 'fuel', 'hourglass']

// ai-usagebar JSON: entries[].metrics[] with { label, percent, detail }
type RawMetric = { label?: string; percent?: number; detail?: string; reset_at?: string | null }
type RawEntry = { id?: string; plan?: string; error?: string | null; metrics?: RawMetric[] }

const toBar = (m: RawMetric): Bar => ({
  label: m.label ?? '?',
  percent: Math.max(0, Math.min(100, Math.round(m.percent ?? 0))),
  detail: m.detail ?? '',
  resetAt: m.reset_at ? Date.parse(m.reset_at) : undefined,
})

function parse(stdout: string, at: number): Usage {
  const entries = (JSON.parse(stdout) as { entries?: RawEntry[] }).entries ?? []
  const byId = (id: string) => entries.find(x => x.id === id)
  const make = (name: string, entry: RawEntry | undefined, pick?: (m: RawMetric) => boolean): Provider => {
    if (!entry) return { name, plan: '', bars: [], error: 'não encontrado' }
    const metrics = (entry.metrics ?? []).filter(pick ?? (() => true))
    return { name, plan: entry.plan ?? '', bars: metrics.map(toBar), error: entry.error ?? undefined }
  }
  return {
    at,
    providers: [
      make('Claude', byId('anthropic')),
      make('Codex', byId('openai')),
      make('Gemini', byId('antigravity'), m => /gemini/i.test(m.label ?? '')),
    ],
  }
}

async function refresh($: EngineInterface) {
  const at = await $.clock.now()
  try {
    const { exitCode, stdout, stderr } = await $.process.run(['ai-usagebar', 'usage', '--json'], { timeoutMs: 45_000 })
    if (exitCode !== 0) throw new Error(stderr.trim() || `exit ${exitCode}`)
    const next = parse(stdout, at)
    await update($, usage, () => next)

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    await update($, usage, prev => ({ providers: prev?.providers ?? [], at, error: msg.slice(0, 200) }))
  }
}

// ---------- economia: RTK medido; Caveman/Ponytail = skill ativa (não medível por sessão) ----------
const savings = atom({ plugin: 'hud-ia', key: 'savings' } as const, null, { shape: 'savings-1' })

async function hasSkill($: EngineInterface, home: string, name: string) {
  const r = await $.process.run(['cmd', '/c', 'if', 'exist', `${home}\\.agents\\skills\\${name}\\SKILL.md`, 'echo', 'ok'], { timeoutMs: 10_000 })
  return r.stdout.includes('ok')
}

async function refreshSavings($: EngineInterface) {
  const home = (await $.env.get('USERPROFILE')) ?? ''
  const [caveman, ponytail] = await Promise.all([hasSkill($, home, 'caveman'), hasSkill($, home, 'ponytail')])
  try {
    const { exitCode, stdout } = await $.process.run(['rtk', 'gain', '--format', 'json'], { timeoutMs: 20_000 })
    if (exitCode !== 0) throw new Error(`rtk exit ${exitCode}`)
    const s = (JSON.parse(stdout) as { summary?: Record<string, number> }).summary ?? {}
    await update($, savings, () => ({
      caveman, ponytail,
      rtk: { commands: s.total_commands ?? 0, saved: s.total_saved ?? 0, input: s.total_input ?? 0, pct: Math.round((s.avg_savings_pct ?? 0) * 10) / 10 },
    }))
  } catch (err) {
    await update($, savings, () => ({ caveman, ponytail, rtk: null, error: String(err).slice(0, 120) }))
  }
}

// ---------- cronômetro e bichinhos (originais) ----------
const countdown = (resetAt: number | undefined, now: number) => {
  if (!resetAt) return ''
  const s = Math.max(0, Math.floor((resetAt - now) / 1000))
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60)
  const two = (n: number) => String(n).padStart(2, '0')
  return d ? `${d}d ${two(h)}h ${two(m)}m` : `${two(h)}:${two(m)}:${two(s % 60)}`
}

const MONSTERS = [
  { body: '▲(•ᴗ•)▲', beam: '~≈', tip: '🔥', color: 'redBright' },
  { body: '◖(°o°)◗', beam: '°o', tip: '○', color: 'cyanBright' },
  { body: 'ϟ(ˋᗜˊ)ϟ', beam: '─ϟ', tip: '⚡', color: 'yellowBright' },
]
const CYCLE = 80 // 20 s a 4 quadros/s

function monsterLine(f: number, w: number): Line {
  const mon = MONSTERS[Math.floor(f / CYCLE) % MONSTERS.length]!
  const p = f % CYCLE
  if (p >= 50) return { text: ' ' }
  if (p < 10 || p >= 40) return { text: `${mon.body} ${p < 10 ? '!' : '…'}`, color: mon.color }
  const len = Math.min(w - 10, Math.round(((p - 10) / 30) * (w - 10)))
  return { text: `${mon.body}${mon.beam.repeat(Math.ceil(len / 2)).slice(0, len)}${mon.tip}`, color: mon.color }
}

// dois gatinhos brancos: andam, trombam, se lambem e se afastam
function catLine(f: number, w: number): string {
  const R = 'ᓚᘏᗢ', L = 'ᗢᘏᓗ'
  const mid = Math.floor(w / 2) - 3
  const p = f % 120
  const at = (a: number, c1: string, b: number, c2: string, extra = '') => {
    const row = Array.from({ length: w }, () => ' ')
    const put = (x: number, s: string) => [...s].forEach((c, i) => { if (x + i >= 0 && x + i < w) row[x + i] = c })
    put(a, c1); put(b, c2); if (extra) put(mid + 1, extra)
    return row.join('')
  }
  if (p < 40) { const x = Math.round((p / 40) * mid); return at(x, R, w - 3 - x, L) }
  if (p < 46) return at(mid - 2, R, mid + 2, L, '💥')
  if (p < 80) return at(mid - 2, R, mid + 2, L, p % 4 < 2 ? '♡' : '~')
  const x = Math.round(((p - 80) / 40) * mid)
  return at(mid - 2 - x, L, mid + 2 + x, R)
}

const k = (n: number) => (n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(1)}K` : String(n))

// ---------- gauges (p = % usado, r = % restante) ----------
type Line = { text: string; color?: string }

const heat = (p: number) => (p >= 90 ? 'red' : p >= 70 ? 'yellow' : 'green')
const fill = (pct: number, w: number, on: string, off: string) => {
  const k = Math.round((pct / 100) * w)
  return on.repeat(k) + off.repeat(w - k)
}
const center = (n: number, w: number, on = '▓', off = ' ') => {
  const left = Math.floor((w - n) / 2)
  return off.repeat(left) + on.repeat(n) + off.repeat(w - n - left)
}

function horizontal(id: StyleId, bar: Bar, i: number, w: number): Line {
  const p = bar.percent
  const r = 100 - p
  switch (id) {
    case 'hp':
      return i === 0
        ? { text: `HP ${fill(r, w, '█', '░')} ${r}/100`, color: r <= 10 ? 'red' : 'redBright' }
        : { text: `MP ${fill(r, w, '█', '░')} ${r}/100`, color: 'blueBright' }
    case 'xp': {
      const lv = Math.min(10, Math.floor(p / 10))
      const within = p >= 100 ? 100 : (p % 10) * 10
      return { text: `Lv${String(lv).padStart(2, '0')} ${fill(within, w, '▰', '▱')} ${p}xp`, color: 'magentaBright' }
    }
    case 'battery':
      return { text: `[${fill(r, w, '█', ' ')}]▌ ${r}%${r <= 10 ? ' ⚠' : ''}`, color: heat(p) }
    default: {
      // comilão: uma criaturinha (:< que mastiga a sua cota de pixels
      const eaten = Math.round((p / 100) * w)
      const mouth = p % 2 === 0 ? '(:<' : '(:='
      return { text: `${'·'.repeat(eaten)}${mouth}${'▪'.repeat(w - eaten)} ${r}%`, color: heat(p) }
    }
  }
}

function vertical(id: StyleId, p: number): Line[] {
  const r = 100 - p
  if (id === 'beer') {
    const k = Math.round(p / 25)
    const handle = [' ', '┐', '│', '┘']
    const rows = [0, 1, 2, 3].map(i => {
      const level = 3 - i
      const body = level < k ? '▓▓▓▓' : level === k && k > 0 ? '░░░░' : '    '
      return { text: `│${body}│${handle[i]}`, color: level < k ? 'yellow' : 'white' }
    })
    return [{ text: ' ____  ', color: 'white' }, ...rows, { text: '└────┘ ', color: 'white' }]
  }
  if (id === 'fuel') {
    const k = Math.round(r / 25)
    const rows = [0, 1, 2, 3].map(i => {
      const level = 3 - i
      const tag = i === 0 ? 'F' : i === 3 ? 'E' : ' '
      return { text: `${tag}│${level < k ? '████' : '    '}│`, color: heat(p) }
    })
    return [{ text: ' ┌──┬─┐' }, ...rows, { text: ' └────┘' }]
  }
  // ampulheta: em cima o que resta, embaixo o que já caiu
  const top = Math.round((r / 100) * 6)
  const t1 = Math.min(2, top)
  const bottom = 6 - top
  const b0 = Math.min(4, bottom)
  const c = heat(p)
  return [
    { text: '══════' },
    { text: `\\${center(top - t1, 4)}/`, color: c },
    { text: ` \\${center(t1, 2)}/ `, color: c },
    { text: top > 0 && bottom < 6 ? '  )(  ' : '  ><  ', color: c },
    { text: ` /${center(bottom - b0, 2)}\\ `, color: c },
    { text: `/${center(b0, 4)}\\`, color: c },
    { text: '══════' },
  ]
}

const short = (label: string) => label.replace(/^Codex /, '').slice(0, 7)

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'hud-ia', description: 'Abre o painel HUD de uso das IAs' })
    const saved = await $.store.get('style')
    if (typeof saved === 'string' && STYLES.some(s => s.id === saved)) {
      await update($, style, () => saved as StyleId)
    }
    // aberto sem pedido, o painel só aparece com terminal de 144+ colunas
    void $.ui.open({ id: PANE, title: 'HUD·IA' }).then(r => {
      if (!r.isPlaced) $.ui.status('HUD·IA: digite /hud-ia para abrir o painel')
    })
    void refresh($)
    void refreshSavings($)
    $.clock.every(POLL_MS, () => (void refresh($), void refreshSavings($)))
    $.clock.every(FRAME_MS, () => void update($, tick, n => n + 1))
    return next(e)
  })

  on('command.run', { command: 'hud-ia' }, async $ => {
    const r = await $.ui.open({ id: PANE, title: 'HUD·IA' })
    void refresh($)
    void refreshSavings($)
    if (!r.isPlaced) return { text: `Painel HUD·IA não abriu: ${r.reason}` }
    $.ui.status(undefined)
    return { text: 'Painel HUD·IA aberto.' }
  })

  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text, Button } = $.ui.resolve(e)
    const data = await read($, usage)
    const eco = await read($, savings)
    const id = await read($, style)
    const f = await read($, tick)
    const now = await $.clock.now()
    const cols = e.viewport?.columns ?? 40
    const w = Math.max(8, Math.min(24, cols - 16))
    const isVertical = VERTICAL.includes(id)
    const choose = (s: StyleId) => async () => {
      await update($, style, () => s)
      await $.store.set('style', s)
    }
    const time = data ? new Date(data.at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '--:--'

    return (
      <Box flexDirection="column">
        <Text bold color="cyanBright">▶ HUD·IA  <Text dimColor>atualizado {time}</Text></Text>
        <Box flexDirection="row" flexWrap="wrap" columnGap={1}>
          {STYLES.map((s, i) => (
            <Button
              key={`style-${s.id}`}
              plain
              hotkey={String(i + 1)}
              label={s.id === id ? `[${s.name}]` : s.name}
              dimColor={s.id !== id}
              onPress={choose(s.id)}
            />
          ))}
          <Button key="refresh" plain hotkey="r" label="Atualizar" onPress={() => refresh($)} />
        </Box>
        {!data && <Text dimColor>Carregando ai-usagebar…</Text>}
        {data?.error && <Text color="red">erro: {data.error}</Text>}
        {data?.providers.map(prov => (
          <Box key={prov.name} flexDirection="column" marginTop={1}>
            <Text bold>
              ◆ {prov.name} <Text dimColor>{prov.plan}</Text>
            </Text>
            {prov.error && <Text color="red">{prov.error.slice(0, 120)}</Text>}
            {isVertical ? (
              <Box flexDirection="row" columnGap={2}>
                {prov.bars.map((bar, i) => (
                  <Box key={`${prov.name}-${i}`} flexDirection="column">
                    {vertical(id, bar.percent).map(line => (
                      <Text color={line.color}>{line.text}</Text>
                    ))}
                    <Text>{bar.percent}%</Text>
                    <Text dimColor>{short(bar.label)}</Text>
                    {bar.resetAt ? <Text dimColor>⏱{countdown(bar.resetAt, now)}</Text> : null}
                  </Box>
                ))}
              </Box>
            ) : (
              prov.bars.map((bar, i) => {
                const line = horizontal(id, bar, i, w)
                return (
                  <Box key={`${prov.name}-${i}`} flexDirection="column">
                    <Text dimColor>
                      {bar.label} · {bar.percent}% usado{bar.resetAt ? ` · ⏱ ${countdown(bar.resetAt, now)}` : ''}
                    </Text>
                    <Text color={line.color}>{line.text}</Text>
                  </Box>
                )
              })
            )}
          </Box>
        ))}
        <Box flexDirection="column" marginTop={1}>
          <Text bold color="greenBright">◆ Economia de tokens</Text>
          {!eco && <Text dimColor>Carregando…</Text>}
          {eco?.rtk && (
            <Box flexDirection="column">
              <Text dimColor>RTK · {eco.rtk.commands} comandos · {k(eco.rtk.saved)} de {k(eco.rtk.input)} poupados</Text>
              <Text color="greenBright">{fill(Math.min(100, eco.rtk.pct), w, '█', '░')} {eco.rtk.pct}%</Text>
            </Box>
          )}
          {eco?.error && <Text color="red">RTK: {eco.error}</Text>}
          {eco && <Text color={eco.caveman ? 'green' : 'red'}>{eco.caveman ? '●' : '○'} Caveman {eco.caveman ? 'ativo' : 'não encontrado'} <Text dimColor>· respostas curtas (não medido)</Text></Text>}
          {eco && <Text color={eco.ponytail ? 'green' : 'red'}>{eco.ponytail ? '●' : '○'} Ponytail {eco.ponytail ? 'ativo' : 'não encontrado'} <Text dimColor>· código mínimo (não medido)</Text></Text>}
        </Box>
        <Box flexDirection="column" marginTop={1}>
          {(() => { const m = monsterLine(f, cols - 2); return <Text color={m.color}>{m.text}</Text> })()}
          <Text color="whiteBright">{catLine(f, cols - 2)}</Text>
        </Box>
      </Box>
    )
  })
}
