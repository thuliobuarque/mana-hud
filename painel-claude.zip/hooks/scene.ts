// Cena em pixel art (meio-bloco ▀: 2 pixels por célula). Sprites originais; cenário procedural.
export const SCENE_ROWS = 9 // 18 pixels de altura

const PAL: Record<string, number> = {
  w: 0xf4f4f8, o: 0x9aa0b4, e: 0x2a2238, p: 0xff8fb1, k: 0x1b1b28, W: 0xffffff, h: 0xff6f9c,
  r: 0xe8452c, R: 0xa82a1a, y: 0xffd23f, O: 0xff8a1f,
  b: 0x3fa7ff, B: 0x1f5fcf, c: 0xbfe8ff,
  Y: 0xffe14d, D: 0xc9a400,
}

// gatinho branco olhando para a direita (6 linhas + pernas)
const CAT = ['......o..o', '......owwo', 'o.....wewe', 'wo....wwpw', '.wwwwwwww.', '.wwwwwwww.']
const LEGS = ['.w.w..w.w.', '..w.w..w.w']

const MONSTERS = [
  { // Brasinha (fogo)
    art: ['....y.....', '...yOy....', '..rrOrrr..', '.rrrrrrrr.', '.rWkrrWkr.', '.rrrrrrrr.', '.rrhrrhrr.', '..rrrrrr..', '..R....R..'],
    shot: [0xfff3a0, 0xffd23f, 0xff8a1f, 0xe8452c],
  },
  { // Gotinha (água)
    art: ['....b.....', '...bbb....', '..bbbbb...', '.bbcbbbbb.', '.bWkbbWkb.', '.bbbbbbbb.', '.bbbkkbbb.', '..bbbbbb..', '...B..B...'],
    shot: [0xffffff, 0xbfe8ff, 0x3fa7ff, 0x1f5fcf],
  },
  { // Faísca (elétrico)
    art: ['.Y......Y.', '.YD....DY.', '..YYYYYY..', '.YYYYYYYY.', '.YWkYYWkY.', '.YYYYYYYY.', '.YhYkkYhY.', '..YYYYYY..', '..D....D..'],
    shot: [0xffffff, 0xfff59d, 0xffe14d, 0xc9a400],
  },
]
const HEART = ['hh.hh', 'hhhhh', '.hhh.', '..h..']
const BURST = ['Y.Y.Y', '.YYY.', 'YYWYY', '.YYY.', 'Y.Y.Y']

const mix = (a: number, b: number, t: number) => {
  const ch = (s: number) => Math.round(((a >> s) & 255) * (1 - t) + ((b >> s) & 255) * t) << s
  return ch(16) | ch(8) | ch(0)
}

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
function b64(u8: Uint8Array) { // tamanho sempre múltiplo de 3 (12 bytes por célula)
  let s = ''
  for (let i = 0; i < u8.length; i += 3) {
    const n = (u8[i]! << 16) | (u8[i + 1]! << 8) | u8[i + 2]!
    s += B64[(n >> 18) & 63]! + B64[(n >> 12) & 63]! + B64[(n >> 6) & 63]! + B64[n & 63]!
  }
  return s
}

/** f = quadro (12 por segundo), hour = hora local para o céu. */
export function drawScene(f: number, cols: number, hour: number): string {
  const W = cols, H = SCENE_ROWS * 2
  const px = new Uint32Array(W * H)
  const set = (x: number, y: number, c: number) => { x = Math.round(x); y = Math.round(y); if (x >= 0 && x < W && y >= 0 && y < H) px[y * W + x] = c }
  const sprite = (rows: string[], x: number, y: number, flip = false) =>
    rows.forEach((row, j) => [...row].forEach((ch, i) => { const c = PAL[ch]; if (c !== undefined) set(flip ? x + row.length - 1 - i : x + i, y + j, c) }))

  // céu: dia, pôr do sol ou noite
  const night = hour < 6 || hour >= 19, dusk = hour >= 17 && hour < 19
  const [top, bot] = night ? [0x0b1030, 0x2a2f5a] : dusk ? [0xff7e5f, 0xfeb47b] : [0x5aa9ff, 0xbfe6ff]
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) px[y * W + x] = mix(top, bot, y / (H - 1))
  if (night) for (let i = 0; i < W / 4; i++) { const x = (i * 37) % W, y = (i * 11) % 9; if ((f + i * 5) % 30 > 3) set(x, y, 0xfff6c8) }
  else for (const [speed, y, len] of [[0.15, 2, 9], [0.08, 5, 6]] as const) { // nuvens
    const x0 = W - ((f * speed) % (W + len + 4))
    for (let i = 0; i < len; i++) { set(x0 + i, y, 0xffffff); if (i > 1 && i < len - 2) set(x0 + i, y - 1, 0xffffff) }
  }

  // chão: grama com tufos e terra
  const G = H - 4
  for (let x = 0; x < W; x++) {
    set(x, G, (x * 7) % 5 === 0 ? 0x2e7d32 : 0x4caf50); set(x, G + 1, 0x43a047)
    set(x, G + 2, 0x8d5a3b); set(x, G + 3, (x * 3) % 7 === 0 ? 0x6d4128 : 0x7a4a2e)
    if ((x * 13) % 11 === 0) set(x, G - 1, 0x66bb6a)
  }

  // monstrinho: entra pulando, carrega, dispara pela barra e sai (ciclo de 20 s)
  const cyc = 240, p = f % cyc, mon = MONSTERS[Math.floor(f / cyc) % MONSTERS.length]!
  const my = G - 9
  if (p < 130) {
    const hop = (t: number) => -Math.abs(Math.sin(t * Math.PI * 3)) * 3
    const x = p < 20 ? -10 + (p / 20) * 11 : p >= 110 ? 1 - ((p - 110) / 20) * 11 : 1
    const y = my + (p < 20 ? hop(p / 20) : p >= 110 ? hop((p - 110) / 20) : (f % 12 < 6 ? 0 : -1))
    if (p >= 20 && p < 30 && f % 2 === 0) for (let a = 0; a < 12; a++) set(x + 4.5 + Math.cos(a) * 6, y + 4 + Math.sin(a) * 5, mon.shot[1]!)
    sprite(mon.art, x, y)
    if (p >= 30 && p < 90) {
      const sx = 11 + ((p - 30) / 60) * (W - 8), sy = my + 4
      for (let t = 1; t <= 6; t++) set(sx - t * 2, sy + (t % 2 ? 0 : 1), mon.shot[Math.min(3, 1 + Math.floor(t / 2))]!)
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) set(sx + dx, sy + dy, mon.shot[Math.abs(dx) + Math.abs(dy) > 1 ? 2 : 1]!)
      set(sx, sy, mon.shot[0]!)
    }
  }

  // gatinhos: andam, trombam, se lambem (corações) e se afastam
  const L = 12, Rr = W - 11, cx = Math.round((L + Rr) / 2), q = f % 240, cy = G - 7
  const step = Math.floor(f / 3) % 2
  const cat = (x: number, facingLeft: boolean, walking: boolean, dy = 0) => {
    sprite(CAT, x, cy + dy, facingLeft); sprite([LEGS[walking ? step : 0]!], x, cy + 6 + dy, facingLeft)
  }
  if (q < 80) { const t = q / 80; cat(L + (cx - 10 - L) * t, false, true); cat(Rr - (Rr - cx) * t, true, true) }
  else if (q < 92) { cat(cx - 11, false, false); cat(cx + 1, true, false); sprite(BURST, cx - 3, cy - 5) }
  else if (q < 170) {
    const lick = Math.floor(q / 6) % 2
    cat(cx - 10 + lick, false, false, -lick); cat(cx, true, false, lick - 1)
    sprite(HEART, cx - 2, cy - 2 - ((q - 92) % 26) / 4)
  } else { const t = (q - 170) / 70; cat(cx - 10 - (cx - 10 - L) * t, true, true); cat(cx + (Rr - cx) * t, false, true) }

  // pixels → células ▀ (frente = pixel de cima, fundo = pixel de baixo)
  const cells = new Uint32Array(W * SCENE_ROWS * 3)
  for (let r = 0; r < SCENE_ROWS; r++) for (let x = 0; x < W; x++) {
    const i = (r * W + x) * 3
    cells[i] = 0x2580; cells[i + 1] = px[2 * r * W + x]!; cells[i + 2] = px[(2 * r + 1) * W + x]!
  }
  return b64(new Uint8Array(cells.buffer))
}
