export type StyleId = 'hp' | 'xp' | 'battery' | 'beer' | 'fuel' | 'hourglass' | 'muncher'
export type Bar = { label: string; percent: number; detail: string; resetAt?: number }
export type Provider = { name: string; plan: string; bars: Bar[]; error?: string }
export type Usage = { providers: Provider[]; at: number; error?: string }
export type Savings = {
  caveman: boolean
  ponytail: boolean
  rtk: { commands: number; saved: number; input: number; pct: number } | null
  error?: string
}

declare module 'claude-code' {
  interface PluginState {
    'hud-ia': { usage: Shaped<Usage | null>; savings: Shaped<Savings | null>; style: StyleId; tick: number }
  }
}
